import React, { useState, useEffect } from 'react';
import axios from 'axios';

const FilterPanel = ({ filters, onFilterChange }) => {
    const [categories, setCategories] = useState([]);
    const [selectedCategories, setSelectedCategories] = useState([]);

    useEffect(()=>{
        const fetchCategories = async () => {
            try{
                const response = await axios.get('http://localhost:5000/api/categories');
                setCategories(response.data);
            }
            catch (err) {
                setError('ошибка при загрузке категории');
                console.error('Error', err);
            }
    };
        fetchCategories();
    }, []);
    const handleCategoryChange = (categorySlug) => {
        const newSelectedCategories = setCategories.include(categorySlug)
        ? selectedCategories.filter(cat => cat !== categorySlug)
        : [...selectedCategories, categorySlug];

        setSelectedCategories(newSelectedCategories);
        onFilterChange({...filters, category: newSelectedCategories.join(',') });
    };

    const handlePriceChange = (field, value) => {
        onFilterChange({...filters, [field]: value});
    };

    const resetFilters = () => {
        setSelectedCategories([]);
        onFilterChange({ category: '', minPrice: '', maxPrice: ''});
    };
    return (
        <div className='filter-panel'>
            <h3>Фильтры</h3>
            {/*по категориям*/}
            <div className='filter-section'>
                <h4>Категории</h4>
                {categories.map(category => (
                <label key={category.id} className='filter-checkbox'>
                <input type='checkbox'
                checked={selectedCategories.includes(category.slug)}
                onChange={() => handleCategoryChange(category.slug)} />
                {category.name} </label>
                ))}
            </div>
            {/*фильтр по цене number, value, onChange*/}


        </div>
    );
};